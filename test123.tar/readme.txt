This is a sample file inside visa.tar for testing purposes.
Keyword: Visa
